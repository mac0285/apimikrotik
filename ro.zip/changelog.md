## Changelog

### Update 09-10-2018 V3.2
1. Penambahan kolom Time Left di Hotspot Active.
2. Penambahan Parent Queue di Add dan Edit User Profile (Bagaimana cara penggunaannya? silakan pelajari Simple Queue Mikrotik).
3. Penyesuaian format Data Limit user menjadi Binary ([base 2](https://www.gbmb.org/gigabytes)).
4. Reformat Uptime.
